import java.sql.*;

import javax.swing.JOptionPane;

public class ConnectDB {
	public static Connection connection() {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://csci366.millersville.edu:5432/a01pokemon_osrothwe", "osrothwe", "archuser5");
			
			String sql = "create extension if not exists pgcrypto";
			Statement stmt = con.createStatement();
			stmt.execute(sql);
			sql = "create table if not exists users(username varchar(30) unique, password varchar(100), first_name varchar(30), last_name varchar(30), email varchar(30), phone varchar(15), primary key(username));";
			stmt.execute(sql);
			return con;
		}
		catch(Exception e) {
			System.out.print(e);
			return null;
		}
	
	}
		
	
}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.DropMode;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.Box;
import javax.swing.JTextPane;
import javax.swing.JEditorPane;
import javax.swing.JFormattedTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.HeadlessException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import javax.swing.SpringLayout;
import net.miginfocom.swing.MigLayout;
import java.sql.*;

import javax.swing.JButton;public class Login {

	
	private static JFrame frame;
	private JTextField txtUsername;
	private JPasswordField passwordField;
	private static JPasswordField Password;
	private JTextField textField;
	private JTextField txtPassword;
	private static JTextField Username;

	
	public static void main(String[] args) throws HeadlessException, SQLException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	}
	public Login() throws SQLException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 200, 228));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 200, 228));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(83, 90, 97, 20);
		txtUsername.setHorizontalAlignment(SwingConstants.LEFT);
		txtUsername.setFont(new Font("Cambria", Font.PLAIN, 19));
		txtUsername.setText("Username:");
		txtUsername.setEditable(false);
		txtUsername.setColumns(6);
		
		panel.setLayout(null);
		panel.add(txtUsername);
		
		txtPassword = new JTextField();
		txtPassword.setBounds(83, 131, 97, 20);
		txtPassword.setHorizontalAlignment(SwingConstants.LEFT);
		txtPassword.setFont(new Font("Cambria", Font.PLAIN, 20));
		txtPassword.setText("Password:");
		panel.add(txtPassword);
		txtPassword.setColumns(6);
		txtPassword.setEditable(false);
		
		Password = new JPasswordField();
		Password.setBounds(192, 131, 133, 20);
		Password.setEditable(true);
		panel.add(Password);
		
		Username = new JTextField();
		Username.setBounds(190, 90, 135, 20);
		panel.add(Username);
		Username.setColumns(10);
		
		JButton Button = new JButton("Login");
		Button.setFont(new Font("Calibri", Font.PLAIN, 15));
		Button.setBounds(157, 44, 89, 23);
		panel.add(Button);
		
		Button.addActionListener(e -> checkLogin());
		
		
	}
	private static void checkLogin() {
		    Connection con = ConnectDB.connection();
		    if(con == null) {
		        JOptionPane.showMessageDialog(frame, "Database connection failed");
		        return;
		    }

		    String sql = "SELECT username FROM users WHERE username=? AND password=crypt(?, password)";

		    try (PreparedStatement pstmt = con.prepareStatement(sql)) {
		        pstmt.setString(1, Username.getText());                  
		        pstmt.setString(2, new String(Password.getPassword())); 

		        ResultSet rs = pstmt.executeQuery(); //Used for update queries

		        if(rs.next()) { 
		            JOptionPane.showMessageDialog(frame, "Logged IN");
		        } else {
		            JOptionPane.showMessageDialog(frame, "Wrong Username or Password");
		        } 
		        //This checks if we have any results from the query

		    } catch (SQLException e) {
		        e.printStackTrace();
		        JOptionPane.showMessageDialog(frame, "Database error: " + e.getMessage());
		    }
		}
}

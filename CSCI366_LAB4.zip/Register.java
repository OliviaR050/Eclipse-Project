import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Font;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JTextArea;

public class Register {

	private static JFrame frame;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtEmail;
	private static JPasswordField passwordField;
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	private JTextField txtPhoneNumber;
	private static JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register window = new Register();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Register() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtUsername.setText("Username:");
		txtUsername.setBounds(97, 63, 85, 18);
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		txtUsername.setEditable(false);
		
		txtPassword = new JTextField();
		txtPassword.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtPassword.setText("Password:");
		txtPassword.setBounds(97, 92, 86, 18);
		panel.add(txtPassword);
		txtPassword.setColumns(10);
		txtPassword.setEditable(false);
		
		txtFirstName = new JTextField();
		txtFirstName.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtFirstName.setText("First Name:");
		txtFirstName.setBounds(96, 123, 86, 20);
		panel.add(txtFirstName);
		txtFirstName.setColumns(10);
		txtFirstName.setEditable(false);
		
		txtLastName = new JTextField();
		txtLastName.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtLastName.setText("Last Name:");
		txtLastName.setBounds(96, 154, 86, 20);
		panel.add(txtLastName);
		txtLastName.setColumns(10);
		txtLastName.setEditable(false);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Calibri", Font.PLAIN, 13));
		txtEmail.setText("Email:");
		txtEmail.setBounds(96, 183, 86, 20);
		panel.add(txtEmail);
		txtEmail.setColumns(10);
		txtEmail.setEditable(false);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Calibri", Font.PLAIN, 13));
		passwordField.setBounds(193, 91, 143, 20);
		panel.add(passwordField);
		
		textField = new JTextField();
		textField.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField.setBounds(192, 60, 144, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField_1.setBounds(192, 121, 143, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField_2.setBounds(192, 152, 144, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField_3.setBounds(192, 181, 144, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 13));
		btnNewButton.setBounds(170, 11, 89, 23);
		panel.add(btnNewButton);
		
		txtPhoneNumber = new JTextField();
		txtPhoneNumber.setFont(new Font("Calibri", Font.PLAIN, 11));
		txtPhoneNumber.setText("Phone Number:");
		txtPhoneNumber.setBounds(96, 214, 86, 20);
		panel.add(txtPhoneNumber);
		txtPhoneNumber.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Calibri", Font.PLAIN, 13));
		textField_4.setColumns(10);
		textField_4.setBounds(192, 212, 144, 20);
		panel.add(textField_4);
		
		btnNewButton.addActionListener(e -> retypePassword());
	}
	private static void retypePassword() {
		Connection con = ConnectDB.connection();
		if(con == null) {
			JOptionPane.showMessageDialog(frame, "Database connection failed");
			return;
		}
		JOptionPane.showMessageDialog(frame, "Retype Password");
		if(passwordsMatch()) {
			register(con);
		}
		else {
			JOptionPane.showMessageDialog(frame, "Passwords do not match");
		}
	}
	private static boolean passwordsMatch() {
		   String original = new String(passwordField.getPassword());
		    
		    JPasswordField retypeField = new JPasswordField();
		    int option = JOptionPane.showConfirmDialog(frame, retypeField, "Retype Password", JOptionPane.OK_CANCEL_OPTION); //OK_CANVEL_OPTION creates the buttons okay and cancel
		    //Option holds what button the user pressed
		    if(option != JOptionPane.OK_OPTION) return false;
		    
		    String retype = new String(retypeField.getPassword());
		    return original.equals(retype);
	}
	private static void register(Connection con) {
	    String username = textField.getText();
	    String password = new String(passwordField.getPassword());
	    String firstName = textField_1.getText();
	    String lastName = textField_2.getText();
	    String email = textField_3.getText();
	    String phone_number = textField_4.getText();

	    String sql = "INSERT INTO users(username, password, first_name, last_name, email, phone) " +
	                 "VALUES (?, crypt(?, gen_salt('bf')), ?, ?, ?, ?) " +
	                 "ON CONFLICT (username) DO NOTHING;"; //In case there is another username with the same name already registered

	    try {
	        java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
	        pstmt.setString(1, username);       
	        pstmt.setString(2, password);       
	        pstmt.setString(3, firstName);      
	        pstmt.setString(4, lastName);       
	        pstmt.setString(5, email);          
	        pstmt.setString(6, phone_number);   
	        //Execute update updates the query
	        int rows = pstmt.executeUpdate(); //How many rows were changed by the database 
	        if (rows > 0) {
	            JOptionPane.showMessageDialog(frame, "User registered successfully!");
	        } else {
	            JOptionPane.showMessageDialog(frame, "Username already exists!");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
	    }
	}
	
		
	}

